from django.urls import path
from .views import homeView, ADetailView , AddPostView , UpdatePostView, DeletePostView,AddCategory,CategoryView,CategoryListView,LikeView,AddCommentView

urlpatterns = [
    path('', homeView .as_view(), name='home'),
    path('Adetail/<int:pk>',ADetailView.as_view(),name='Adetial'), 
    path('add_post/',AddPostView.as_view(), name='add_post'),
    path('Adetail/edit/<int:pk>',UpdatePostView.as_view(),name='update_post'),
    path('Adetail/delete/<int:pk>',DeletePostView.as_view(),name='delete_post'),
    path('add_category/',AddCategory.as_view(),name='add_category'),
    path('category/<str:cats>/',CategoryView,name='category'),
    path('category-list/',CategoryListView,name='category-list'),
    # path('like/<int:pk>',LikeView,name='like_post'),
    path('like/<int:pk>', LikeView, name='like_post'),
    path('artical/<int:pk>/comment/',AddCommentView.as_view(), name='add_comment'),

]